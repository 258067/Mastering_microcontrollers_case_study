//qemu-system-gnuarmeclipse.exe -M STM32F4-Discovery -mcu STM32F407VG -kernel finalled.elf -> cygwin command to run qemu
#include"stm32f407xx.h"
#include "stm32f407xx_gpio_driver.h"
#include <stdint.h>
void delay(void)
{
	for(uint32_t i=0;i<833333333/2;i++);
}
void small_delay(void)
{
	for(uint32_t i=0;i<100000000;i++);
}

int main(void)
{
	GPIO_handle_t ignition_is_on;
	ignition_is_on.pGPIOx = GPIOD;
	ignition_is_on.GPIO_pinconfig.GPIO_pinnumber = GPIO_PIN_NO_12;
	ignition_is_on.GPIO_pinconfig.GPIO_pinmode = GPIO_MODE_OUTPUT;
	ignition_is_on.GPIO_pinconfig.GPIO_pinspeed = GPIO_SPEED_VHIGH;
	ignition_is_on.GPIO_pinconfig.GPIO_pinpupdcontrol = GPIO_NO_PUPD;
	ignition_is_on.GPIO_pinconfig.GPIO_pinoptype = GPIO_OP_TYPE_PUSHPULL;

	GPIO_handle_t seat_belt_not_fastened1;
	seat_belt_not_fastened1.pGPIOx = GPIOD;
	seat_belt_not_fastened1.GPIO_pinconfig.GPIO_pinnumber =  GPIO_PIN_NO_12;
	seat_belt_not_fastened1.GPIO_pinconfig.GPIO_pinmode = GPIO_MODE_OUTPUT;
	seat_belt_not_fastened1.GPIO_pinconfig.GPIO_pinspeed = GPIO_SPEED_VHIGH;
	seat_belt_not_fastened1.GPIO_pinconfig.GPIO_pinpupdcontrol = GPIO_NO_PUPD;
	seat_belt_not_fastened1.GPIO_pinconfig.GPIO_pinoptype = GPIO_OP_TYPE_PUSHPULL;

	GPIO_handle_t seat_belt_not_fastened2;
	seat_belt_not_fastened2.pGPIOx = GPIOD;
	seat_belt_not_fastened2.GPIO_pinconfig.GPIO_pinnumber =  GPIO_PIN_NO_13;
	seat_belt_not_fastened2.GPIO_pinconfig.GPIO_pinmode = GPIO_MODE_OUTPUT;
	seat_belt_not_fastened2.GPIO_pinconfig.GPIO_pinspeed = GPIO_SPEED_VHIGH;
	seat_belt_not_fastened2.GPIO_pinconfig.GPIO_pinpupdcontrol = GPIO_NO_PUPD;
	seat_belt_not_fastened2.GPIO_pinconfig.GPIO_pinoptype = GPIO_OP_TYPE_PUSHPULL;

	GPIO_handle_t seat_belt_not_fastened3;
	seat_belt_not_fastened3.pGPIOx = GPIOD;
	seat_belt_not_fastened3.GPIO_pinconfig.GPIO_pinnumber =  GPIO_PIN_NO_14;
	seat_belt_not_fastened3.GPIO_pinconfig.GPIO_pinmode = GPIO_MODE_OUTPUT;
	seat_belt_not_fastened3.GPIO_pinconfig.GPIO_pinspeed = GPIO_SPEED_VHIGH;
	seat_belt_not_fastened3.GPIO_pinconfig.GPIO_pinpupdcontrol = GPIO_NO_PUPD;
	seat_belt_not_fastened3.GPIO_pinconfig.GPIO_pinoptype = GPIO_OP_TYPE_PUSHPULL;

	GPIO_handle_t seat_belt_not_fastened4;
	seat_belt_not_fastened4.pGPIOx = GPIOD;
	seat_belt_not_fastened4.GPIO_pinconfig.GPIO_pinnumber =  GPIO_PIN_NO_15;
	seat_belt_not_fastened4.GPIO_pinconfig.GPIO_pinmode = GPIO_MODE_OUTPUT;
	seat_belt_not_fastened4.GPIO_pinconfig.GPIO_pinspeed = GPIO_SPEED_VHIGH;
	seat_belt_not_fastened4.GPIO_pinconfig.GPIO_pinpupdcontrol = GPIO_NO_PUPD;
	seat_belt_not_fastened4.GPIO_pinconfig.GPIO_pinoptype = GPIO_OP_TYPE_PUSHPULL;

	GPIO_handle_t GPIObutton;
	GPIObutton.pGPIOx=GPIOA;
	GPIObutton.GPIO_pinconfig.GPIO_pinnumber = GPIO_PIN_NO_0;
	GPIObutton.GPIO_pinconfig.GPIO_pinmode = GPIO_MODE_INPUT;
	GPIObutton.GPIO_pinconfig.GPIO_pinspeed = GPIO_SPEED_LOW;
	GPIObutton.GPIO_pinconfig.GPIO_pinpupdcontrol = GPIO_NO_PUPD;
	GPIObutton.GPIO_pinconfig.GPIO_pinoptype = GPIO_OP_TYPE_PUSHPULL;

	GPIO_PeriClockControl(GPIOD, ENABLE);
	GPIO_PeriClockControl(GPIOA, ENABLE);
	GPIO_init(&ignition_is_on);
	GPIO_init(&seat_belt_not_fastened1);
	GPIO_init(&seat_belt_not_fastened2);
	GPIO_init(&seat_belt_not_fastened3);
	GPIO_init(&seat_belt_not_fastened4);
	GPIO_init(&GPIObutton);


	GPIO_highoutputpin(GPIOD, GPIO_PIN_NO_12);
	delay();
	GPIO_lowoutputpin(GPIOD, GPIO_PIN_NO_12);
	int count=0;
	while(1)
	{
		if (GPIO_readfrominputpin(GPIOA, GPIO_PIN_NO_0) == ENABLE)
		{
			count=count+1;
		}
		if (count == 1)
		{
		GPIO_toggleoutputpin(GPIOD,GPIO_PIN_NO_12);
		//small_delay();
		GPIO_toggleoutputpin(GPIOD,GPIO_PIN_NO_13);
		//small_delay();
		GPIO_toggleoutputpin(GPIOD,GPIO_PIN_NO_14);
		//small_delay();
		GPIO_toggleoutputpin(GPIOD,GPIO_PIN_NO_15);
		//small_delay();
		small_delay();
		}
		if (count == 2)
		{
			for(int i=0;i<833333333/2;i++)
			{
			GPIO_lowoutputpin(GPIOD,GPIO_PIN_NO_12);
			GPIO_lowoutputpin(GPIOD,GPIO_PIN_NO_13);
			GPIO_lowoutputpin(GPIOD,GPIO_PIN_NO_15);
			GPIO_toggleoutputpin(GPIOD,GPIO_PIN_NO_14);
			small_delay();
			small_delay();
			GPIO_lowoutputpin(GPIOD,GPIO_PIN_NO_14);
			small_delay();
			small_delay();
			}
		}
		if (count==3)
		{
			GPIO_lowoutputpin(GPIOD,GPIO_PIN_NO_14);
			GPIO_toggleoutputpin(GPIOD,GPIO_PIN_NO_13);
			small_delay();
			GPIO_lowoutputpin(GPIOD,GPIO_PIN_NO_13);
			small_delay();
		}


	}
	return 0;
}
