/*
 * stm32f407xx_gpio_driver.h
 *
 *  Created on: Sep 20, 2021
 *      Author: shrey
 */

#ifndef INC_STM32F407XX_GPIO_DRIVER_H_
#define INC_STM32F407XX_GPIO_DRIVER_H_
#include "stm32f407xx.h"

typedef struct
{
	uint8_t GPIO_pinnumber;
	uint8_t GPIO_pinmode;
	uint8_t GPIO_pinspeed;
	uint8_t GPIO_pinpupdcontrol;
	uint8_t GPIO_pinoptype;
	uint8_t GPIO_pinaltfunmode;
}GPIO_pinconfig_t;

typedef struct
{
	GPIO_Regdef_t *pGPIOx; //This holds the base address of the GPIO port to which the pin belongs to
	GPIO_pinconfig_t GPIO_pinconfig; //This holds the pin configuration settings



}GPIO_handle_t;
/*
 * GPIO_Pin number macros
 */

#define GPIO_PIN_NO_0		0
#define GPIO_PIN_NO_1		1
#define GPIO_PIN_NO_2		2
#define GPIO_PIN_NO_3		3
#define GPIO_PIN_NO_4		4
#define GPIO_PIN_NO_5		5
#define GPIO_PIN_NO_6		6
#define GPIO_PIN_NO_7		7
#define GPIO_PIN_NO_8		8
#define GPIO_PIN_NO_9		9
#define GPIO_PIN_NO_10		10
#define GPIO_PIN_NO_11		11
#define GPIO_PIN_NO_12		12
#define GPIO_PIN_NO_13		13
#define GPIO_PIN_NO_14		14
#define GPIO_PIN_NO_15		15

/*
 * GPIO pinmode macros
 */

#define GPIO_MODE_INPUT		0
#define GPIO_MODE_OUTPUT	1
#define GPIO_MODE_ALTFN		2
#define GPIO_MODE_ANALOG	3

/*
 * GPIO pinspeed macros
 */

#define GPIO_SPEED_LOW		0
#define GPIO_SPEED_MEDIUM	1
#define GPIO_SPEED_HIGH		2
#define GPIO_SPEED_VHIGH	3

/*
 * GPIO pin pupd control macros
 */

#define GPIO_NO_PUPD		0
#define GPIO_PULLUP			1
#define GPIO_PULLDOWN		2

/*
 * GPIO pin output type macros
 */

#define GPIO_OP_TYPE_PUSHPULL	0
#define GPIO_OP_TYPE_OPENDRAIN  1

/*
 *
 * User defined APIs
 */
void GPIO_init(GPIO_handle_t *pGPIOhandle);
void GPIO_Deinit(GPIO_Regdef_t *pGPIOx);
/*
 * Peripheral clock
 */
void GPIO_PeriClockControl(GPIO_Regdef_t *pGPIOx,uint8_t ENorDI);
/*
 * Data read and write
 */

/*
 * @Brief: GPIO port input data register
 * @param1: pGPIOx is the base address of any GPIO peripheral
 * @param2: pinNumber is given by the user
 * @return: none
 */
uint8_t GPIO_readfrominputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber);
uint16_t GPIO_readfrominputport(GPIO_Regdef_t *pGPIOx);
void GPIO_writetooutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber, uint8_t value);
void GPIO_writetooutputport(GPIO_Regdef_t *pGPIOx, uint8_t value);
void GPIO_toggleoutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber);
void GPIO_highoutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber);
void GPIO_lowoutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber);
void GPIO_all_blink(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber1,uint8_t pinNumber2,uint8_t pinNumber3,uint8_t pinNumber4);




#endif /* INC_STM32F407XX_GPIO_DRIVER_H_ */
