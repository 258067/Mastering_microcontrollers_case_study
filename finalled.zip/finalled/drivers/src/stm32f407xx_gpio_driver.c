/*
 * stm32f407xx_gpio_driver.c
 *
 *  Created on: Sep 20, 2021
 *      Author: shrey
 */
#include "stm32f407xx_gpio_driver.h"
/*
 *
 * User defined APIs
 */

/*
 * Peripheral clock
 */
void GPIO_PeriClockControl(GPIO_Regdef_t *pGPIOx,uint8_t ENorDI)
{
	if (ENorDI==ENABLE)
	{
		if(pGPIOx==GPIOA)
		{
			GPIOA_PCLK_EN();
		}
		else if(pGPIOx==GPIOB)
		{
			GPIOB_PCLK_EN();
		}
		else if(pGPIOx==GPIOC)
		{
			GPIOC_PCLK_EN();
		}
		else if(pGPIOx==GPIOD)
		{
			GPIOD_PCLK_EN();
		}
		else if(pGPIOx==GPIOE)
		{
			GPIOE_PCLK_EN();
		}
		else if(pGPIOx==GPIOF)
		{
			GPIOF_PCLK_EN();
		}
		else if(pGPIOx==GPIOG)
		{
			GPIOG_PCLK_EN();
		}
		else if(pGPIOx==GPIOH)
		{
			GPIOH_PCLK_EN();
		}
		else if(pGPIOx==GPIOI)
		{
			GPIOI_PCLK_EN();
		}
		else if(pGPIOx==GPIOJ)
		{
			GPIOJ_PCLK_EN();
		}
		else
		{
			GPIOK_PCLK_EN();
		}
	}
	else
	{
		if(pGPIOx==GPIOA)
		{
			GPIOA_PCLK_DI();
		}
		else if(pGPIOx==GPIOB)
		{
			GPIOB_PCLK_DI();
		}
		else if(pGPIOx==GPIOC)
		{
			GPIOC_PCLK_DI();
		}
		else if(pGPIOx==GPIOD)
		{
			GPIOD_PCLK_DI();
		}
		else if(pGPIOx==GPIOE)
		{
			GPIOE_PCLK_DI();
		}
		else if(pGPIOx==GPIOF)
		{
			GPIOF_PCLK_DI();
		}
		else if(pGPIOx==GPIOG)
		{
			GPIOG_PCLK_DI();
		}
		else if(pGPIOx==GPIOH)
		{
			GPIOH_PCLK_DI();
		}
		else if(pGPIOx==GPIOI)
		{
			GPIOI_PCLK_DI();
		}
		else if(pGPIOx==GPIOJ)
		{
			GPIOJ_PCLK_DI();
		}
		else
		{
			GPIOK_PCLK_DI();
		}
	}
}
void GPIO_init(GPIO_handle_t *pGPIOhandle)
{
	uint32_t temp=0;
	//1. Configure the mode
	temp = (pGPIOhandle->GPIO_pinconfig.GPIO_pinmode << (2*pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber));
	pGPIOhandle->pGPIOx->MODER &=~(0x3 << (2*pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber));//clear the bit
	pGPIOhandle->pGPIOx->MODER |=temp; //set the bit
	temp=0;
	//2. configure the pin speed
	temp=pGPIOhandle->GPIO_pinconfig.GPIO_pinspeed << (2*pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber);
	pGPIOhandle->pGPIOx->OSPEEDR &=~(0x3 << (2*pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber));
	pGPIOhandle->pGPIOx->OSPEEDR |=temp;
	temp=0;
	//3. configure pushpull type
	temp=pGPIOhandle->GPIO_pinconfig.GPIO_pinpupdcontrol << (2*pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber);
	pGPIOhandle->pGPIOx->PUPDR &=~(0x3 << (2*pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber));
	pGPIOhandle->pGPIOx->PUPDR |=temp;
	temp=0;
	//4. configure output type
	temp=pGPIOhandle->GPIO_pinconfig.GPIO_pinoptype << (pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber);
	pGPIOhandle->pGPIOx->OTYPER &=~(0x1 << (pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber));
	pGPIOhandle->pGPIOx->OTYPER |=temp;
	temp=0;
	//5. configure alternating function mode
	if (pGPIOhandle->GPIO_pinconfig.GPIO_pinmode == GPIO_MODE_ALTFN)
	{
		uint8_t temp1,temp2;
		temp1=pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber/8;
		temp2=pGPIOhandle->GPIO_pinconfig.GPIO_pinnumber%8;
		pGPIOhandle->pGPIOx->AFR[temp1] &=~(0xf << (4*temp2));
		pGPIOhandle->pGPIOx->AFR[temp1] |= (pGPIOhandle->GPIO_pinconfig.GPIO_pinaltfunmode << (4*temp2));
	}


}
void GPIO_Deinit(GPIO_Regdef_t *pGPIOx)
{
	if(pGPIOx==GPIOA)
	{
		GPIOA_REG_RESET();
	}
	else if(pGPIOx==GPIOB)
	{
		GPIOB_REG_RESET();
	}
	else if(pGPIOx==GPIOC)
	{
		GPIOC_REG_RESET();
	}
	else if(pGPIOx==GPIOD)
	{
		GPIOD_REG_RESET();
	}
	else if(pGPIOx==GPIOE)
	{
		GPIOE_REG_RESET();
	}
	else if(pGPIOx==GPIOF)
	{
		GPIOF_REG_RESET();
	}
	else if(pGPIOx==GPIOG)
	{
		GPIOG_REG_RESET();
	}
	else if(pGPIOx==GPIOH)
	{
		GPIOH_REG_RESET();
	}
	else if(pGPIOx==GPIOI)
	{
		GPIOI_REG_RESET();
	}
	else if(pGPIOx==GPIOJ)
	{
		GPIOJ_REG_RESET();
	}
	else
	{
		GPIOK_REG_RESET();
	}

}

/*
 * Data read and write
 */
uint8_t GPIO_readfrominputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber)
{
	uint8_t value;
	value=(uint8_t)((pGPIOx->IDR >> pinNumber)&0x00000001);
	return value;

}
uint16_t GPIO_readfrominputport(GPIO_Regdef_t *pGPIOx)
{
	uint16_t value;
	value= (uint16_t)(pGPIOx->IDR);
	return value;

}
void GPIO_writetooutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber, uint8_t value)
{
	if(value==GPIO_PIN_SET)
	{
		pGPIOx->ODR |=(1<<pinNumber);
	}
	else
	{
		pGPIOx->ODR &=~(1<<pinNumber);
	}

}
void GPIO_writetooutputport(GPIO_Regdef_t *pGPIOx, uint8_t value)
{
	pGPIOx->ODR = value;

}
void GPIO_toggleoutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber)
{
	pGPIOx->ODR ^= (1<<pinNumber);

}
void GPIO_highoutputpin(GPIO_Regdef_t *pGPIOx ,uint8_t pinNumber)
{
	pGPIOx->ODR = (1<<pinNumber);
}
void GPIO_lowoutputpin(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber)
{
	pGPIOx->ODR = (0<<pinNumber);
}
/*void GPIO_all_blink(GPIO_Regdef_t *pGPIOx, uint8_t pinNumber1,uint8_t pinNumber2,uint8_t pinNumber3,uint8_t pinNumber4)
{
	pGPIOx->ODR = (1<<pinNumber1);
	pGPIOx->ODR = (1<<pinNumber2);
	pGPIOx->ODR = (1<<pinNumber3);
	pGPIOx->ODR = (1<<pinNumber4);
}*/


